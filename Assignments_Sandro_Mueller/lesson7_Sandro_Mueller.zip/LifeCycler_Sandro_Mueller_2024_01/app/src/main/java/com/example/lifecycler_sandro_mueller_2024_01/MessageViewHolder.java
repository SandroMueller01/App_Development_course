package com.example.lifecycler_sandro_mueller_2024_01;

import android.view.View;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

public class MessageViewHolder extends RecyclerView.ViewHolder {

    TextView txtMessage;
    TextView txtTime;
    View view;

    MessageViewHolder(View itemView) {
        super(itemView);
        txtMessage = itemView.findViewById(R.id.txtMessage);
        txtTime = itemView.findViewById(R.id.txtTime);
        view = itemView;
    }
}
