package com.example.lifecycler_sandro_mueller_2024_01;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<MessageViewHolder> {

    List<MessageData> list;
    Context context;

    RecyclerViewAdapter(List<MessageData> list, Context context) {
        this.list = list;
        this.context = context;

    }

    @NonNull
    @Override
    public MessageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);

        // Inflate the layout
        View messageView = inflater.inflate(R.layout.message, parent, false);

        return new MessageViewHolder(messageView);
    }

    @Override
    public void
    onBindViewHolder(final MessageViewHolder viewHolder,
                     final int position) {
        viewHolder.txtMessage.setText(list.get(position).message);
        viewHolder.txtTime.setText(list.get(position).time);

    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}

