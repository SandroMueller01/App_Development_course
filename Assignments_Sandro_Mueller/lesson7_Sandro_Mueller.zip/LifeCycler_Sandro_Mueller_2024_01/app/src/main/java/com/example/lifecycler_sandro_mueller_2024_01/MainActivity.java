package com.example.lifecycler_sandro_mueller_2024_01;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerViewAdapter adapter;
    RecyclerView recyclerView;
    List<MessageData> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerViewEvents);
        adapter = new RecyclerViewAdapter(list, getApplicationContext());
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));

        setData("onCreate", Calendar.getInstance().getTime().toString());

        FloatingActionButton fabDestroy = findViewById(R.id.fab_Destroy);
        fabDestroy.setOnClickListener(v -> {
            Log.d("OnLifeCycle", "Finish it!!!!!");
            MainActivity.this.finish();
        });
    }

    private void setData(String message, String time) {
        list.add(new MessageData(message, time));
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void onStart() {
        super.onStart();
        setData("onStart", Calendar.getInstance().getTime().toString());
    }

    @Override
    protected void onResume() {
        super.onResume();
        setData("onResume", Calendar.getInstance().getTime().toString());
    }

    @Override
    protected void onPause() {
        super.onPause();
        setData("onPause", Calendar.getInstance().getTime().toString());
    }

    @Override
    protected void onStop() {
        super.onStop();
        setData("onStop", Calendar.getInstance().getTime().toString());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        setData("onDestroy", Calendar.getInstance().getTime().toString());
    }
}
