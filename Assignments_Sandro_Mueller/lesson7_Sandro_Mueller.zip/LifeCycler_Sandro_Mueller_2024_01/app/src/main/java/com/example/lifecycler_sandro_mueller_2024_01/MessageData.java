package com.example.lifecycler_sandro_mueller_2024_01;

public class MessageData {

    String message;
    String time;

    MessageData(String message, String time) {
        this.message = message;
        this.time = time;
    }
}

